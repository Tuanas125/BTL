/*const Uint8 * keystates = SDL_GetKeyboardState(NULL);
        if(keystates[SDL_SCANCODE_D])
        {
            ball.changeX(ball.getX()+5);
        }
        if(keystates[SDL_SCANCODE_A])
        {
            ball.changeX(ball.getX()-5);
        }
        if(keystates[SDL_SCANCODE_S])
        {
            ball.changeY(ball.getY()+5);
        }
        if(keystates[SDL_SCANCODE_W])
        {
            ball.changeY(ball.getY()-5);
        }*/
